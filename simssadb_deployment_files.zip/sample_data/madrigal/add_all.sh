#!/bin/bash

python software_adder.py
python encoder_adder.py
python instrument_adder.py
python genre_adder.py
python person_adder.py
python collection_adder.py
python work_source_adder.py
python location_adder.py